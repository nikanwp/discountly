import { __ } from '@wordpress/i18n';

const translations = {
    global_discount: __('Global Discount','discountly'),
    cart_discount: __('Cart Discount','discountly'),
}
export default translations